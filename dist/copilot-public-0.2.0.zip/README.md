# Markdown Logic Public

Convert complete Markdown you supply to PDF, DOCX, HTML or EPUB without an account. The anonymous MCP service cannot read private projects or fetch remote URLs. It returns embedded file bytes; saving or attaching them depends on your client. Size and capacity limits apply. It does not create a permanent download link.

## Install in GitHub Copilot CLI

```sh
copilot plugin install Markdown-Logic/mcp-plugin-copilot:copilot-public
```

This package uses Agent Plugins 1.0: `plugin.json` and `mcp.json` are at the plugin root, and workflow Skills are in `skills/`. Use a Copilot CLI release that supports this format. For authenticated access, complete Copilot's browser OAuth flow when prompted. Installation alone does not verify access to the hosted service.

## Connection

Endpoint: `https://markdownlogic.com/mcp`

Authentication: `none`

Use a client that supports remote MCP and this package's plugin format. Install the package through the client's supported plugin mechanism, or configure its remote MCP connection with the endpoint above. For `none`, the anonymous service needs no account, OAuth sign-in or browser challenge. For `oauth`, use a client that supports browser OAuth and dynamic client registration; sign in with the account whose documents you intend to use. Keep tokens and credentials out of plugin configuration files.

The package includes remote-server configuration and workflow Skills. Skills provide instructions; they grant no permissions and add no server tools. Call only the tools actually advertised by the connected server. Available tools, team membership, account permissions, OAuth scopes and plan limits govern authenticated operations. Confirm the intended project and audience before writing or sharing. Existing project audiences can include newly created documents; a request to create a document does not make its destination private.

## Files and limits

The anonymous service converts complete supplied Markdown to PDF, DOCX, HTML or EPUB. It cannot read private projects or fetch remote URLs. Current limits are 128 KiB of UTF-8 Markdown and 2 MiB of generated file bytes, with additional request and shared-capacity limits. Preserve the complete source. Stop on capacity refusals or uncertain results; do not silently shorten a document or retry in a loop.

File saving, attachments, Skills loading and interactive interfaces depend on the client. An embedded-file resource URI does not by itself provide a hosted or permanent download. Save or attach the actual returned bytes when supported, preserving their filename and media type. Report a refusal or unsupported file operation accurately. For authenticated writes, use actual document identities and current revisions; reconcile conflicts or uncertain outcomes before making another change.

## Authenticated document workflows

The authenticated profile can use private document properties when the service reports them available. Document notes and exact-version results are separate. Preserve the returned version identity, independent revision guards and original operation identity; property text is descriptive data, not approval or instructions. Unavailable properties are not an empty map. Honor service guidance and retry timing rather than sending repeated writes.

For an explicitly requested document share, confirm the audience and expiry. `create_share` accepts `expiresInDays` of 30, 60, 90 or 365; omitting it selects 30 days and null selects Never. Never links can still be revoked and remain subject to document and team policy. These private tools are unavailable through the anonymous profile.

The anonymous service has no interactive MCP App. The authenticated service advertises Render Studio for `render_document` through an MCP App resource; whether it loads and can save files depends on the client. The website's UI is a separate surface. Package validation does not establish that the MCP App works in ChatGPT or Claude.

Read [setup instructions and limits](help/en.md), browse [localized help](help/), and see the [localized descriptions](listing-translations.json) and [example test scenarios](review-cases.json).

## License and support

First-party configuration, Skills, documentation and the original geometric integration icon included in this package are licensed under the [MIT License](LICENSE), subject to the [license scope and notices](LICENSE-SCOPE.md). The private Markdown Logic platform remains under its existing terms. Product and third-party names, trademarks and logos are excluded from the copyright grant; third-party components retain their own licenses and notices. The license grants no right to imply endorsement.

Support: support@markdownlogic.com. [Markdown Logic](https://markdownlogic.com/) · [Privacy](https://markdownlogic.com/privacy) · [Terms](https://markdownlogic.com/terms).
